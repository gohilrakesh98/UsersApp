﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserApp.APICalls;
using UserApp.Model;

namespace UserApp
{
    public class ServiceAgent
    {
        private readonly APICall _apiCall;

        public ServiceAgent() : this(new APICall())
        {
        }
        public ServiceAgent(APICall apiCall)
        {
            _apiCall = apiCall;
        }

        public async Task<APIResponse> Add(User user)
        {
            return await _apiCall .Add(user);
        }

        public async Task<ObservableCollection<User>> GetAll()
        {
            var users = await _apiCall.GetUsers();

            var Users = new ObservableCollection<User>();
            foreach (var item in users)
            {
                Users.Add(item);
            }
            return Users;
        }
    }
}
