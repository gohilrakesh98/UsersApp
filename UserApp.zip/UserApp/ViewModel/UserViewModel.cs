﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserApp.Model;

namespace UserApp.ViewModel
{
    class UserViewModel : INotifyPropertyChanged
    {
        ObservableCollection<User> _users;

        ServiceAgent serviceAgent;
        public AsyncRelayCommand GetCommand { get; set; }

        public UserViewModel()
        {
            GetCommand = new AsyncRelayCommand(async () => await GetAllUsers());
        }
        public ObservableCollection<User> Users
        {
            get
            {
                return _users;
            }
            set
            {
                _users = value;
                NotifyOfPropertyChange("Users");
            }
        }

        public async Task GetAllUsers()
        {
            serviceAgent = new ServiceAgent();
            Users = await serviceAgent.GetAll();
        }

        #region INotifyPropertyChanged Users
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyOfPropertyChange(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
