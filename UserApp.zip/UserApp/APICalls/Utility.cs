﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace UserApp.APICalls
{
    public static class Utility
    {
        public static StringContent ToJsonString<T>(this T currentObject)
        {
            string json = JsonConvert.SerializeObject(currentObject);
            return new StringContent(json, UnicodeEncoding.UTF8, "application/json");
        }
    }
}
