﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;

namespace UserApp.APICalls
{
    public static class CommonAPIClient
    {
        public static string BaseAddress { get; private set; }
        public static string API_User { get; private set; }

        static CommonAPIClient()
        {
            SetAllConfiguration();
        }

        private static void SetAllConfiguration()
        {
            BaseAddress = System.Configuration.ConfigurationManager.AppSettings[nameof(BaseAddress)];
            API_User = System.Configuration.ConfigurationManager.AppSettings[nameof(API_User)];
        }

        public static HttpClient GetHttpClient()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(CommonAPIClient.BaseAddress);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return client;
        }

    }
}
