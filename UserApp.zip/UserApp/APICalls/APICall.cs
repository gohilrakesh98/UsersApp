﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UserApp.Model;

namespace UserApp.APICalls
{
    public class APICall
    {
        public async Task<List<User>> GetUsers()
        {
            using (var client = CommonAPIClient.GetHttpClient())
            {

                var response = await client.GetAsync($"{CommonAPIClient.API_User}");

                if (response.IsSuccessStatusCode)
                {
                    var str = response.Content.ReadAsAsync<object>().Result;
                    var contentData = JsonConvert.DeserializeObject<IEnumerable<User>>(str.ToString());
                    return contentData.ToList();
                }

                return new List<User>();
            }
        }

        public async Task<APIResponse> Add(User user)
        {
            using (var client = CommonAPIClient.GetHttpClient())
            {
                var response = await client.PostAsync(CommonAPIClient.API_User, user.ToJsonString());
                return APICall.GetHttpResponseMessage(response);
            }
        }

        public async Task<APIResponse> Update(User user)
        {
            using (var client = CommonAPIClient.GetHttpClient())
            {
                var response = await client.PutAsync(CommonAPIClient.API_User, user.ToJsonString());
                return APICall.GetHttpResponseMessage(response);
            }
        }

        public async Task<bool> Delete(List<int> idsToDelete)
        {
            using (var client = CommonAPIClient.GetHttpClient())
            {
                string ids = string.Join(",", idsToDelete.Select(n => n.ToString()).ToArray());
                var response = await client.PutAsync(CommonAPIClient.API_User + "?idsToDelete=" + ids, ids.ToJsonString());

                return response.IsSuccessStatusCode;
            }
        }

        public static APIResponse GetHttpResponseMessage(HttpResponseMessage httpResponseMessage)
        {
            return new APIResponse
            {
                IsSuccess = httpResponseMessage.IsSuccessStatusCode,
                //Message = httpResponseMessage.RequestMessage.Headers.ToString()
            };
        }
        

        
    }

}
